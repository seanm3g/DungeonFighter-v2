# Task List


---

*Tasks will be updated as the project progresses.* 

## Action Combo System Tasks

1. **Design Action Data Structures**
   - Define the four actions (Taunt, Jab, Stun, Crit) with properties: damage %, length, description, and special effects.
2. **Implement Combo Logic**
   - Create logic to handle action sequences, dice rolls (1d20 + bonus), and combo progression.
   - Implement damage amplification (1.85x per successful combo step).
   - Reset combo on failed roll.
3. **Integrate Loot and Bonuses**
   - Add loot that grants +1 (or more) to action rolls.
   - Ensure loot bonuses are factored into combo checks.
4. **Update Combat System**
   - Integrate the action combo system into the main combat loop.
   - Ensure compatibility with existing character and enemy systems.
5. **Testing**
   - Write unit tests for action resolution, combo progression, and loot effects.
   - Test edge cases (e.g., max combo, repeated failures, stacking loot bonuses).
6. **Documentation**
   - Update documentation to reflect new mechanics and usage. 