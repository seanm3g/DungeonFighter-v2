# RPG Game Project

## Getting Started

1. Ensure you have the .NET SDK installed.
2. Build the project using `dotnet build`.
3. Run the game using `dotnet run` from the project directory.

## Graphical User Interface (GUI)

A desktop GUI is implemented using WinForms for a modern, user-friendly experience. You can run the GUI by building and running the GUI project:

1. Build the solution: `dotnet build`
2. Run the GUI: `dotnet run --project RPGGame.GUI`

### GUI Features
- Fighter Stats panel (Level, XP, HP, etc.)
- Event Log panel (scrollable log of game events)
- Equipment panel (equip/unequip items, inventory grid)
- Dungeons panel (dungeon list, progress bar, selection)
- Interactive: Click to equip/unequip items and select dungeons

## Project Structure

- `Code/Character.cs` - Player and character logic
- `Code/Enemy.cs` - Enemy logic
- `Code/Item.cs` - Item logic
- `Code/Dice.cs` - Random number generation
- `Code/Combat.cs` - Combat system
- `Code/Environment.cs` - Environment logic
- `Code/Game.cs` - Main game loop and entry point
- `RPGGame.GUI/` - WinForms GUI project for the game

## Development Approach

- Layer-by-layer, test-driven development
- Each class and feature is tested before integration

## Running Tests

- Use `dotnet test` to run all unit tests

---

*See OVERVIEW.md for more details on the game and its features.* 