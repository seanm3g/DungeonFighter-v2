# Game Overview

## General Description
This project is a layer-by-layer, test-driven development of a turn-based RPG game written in C#. The game is designed to be modular, with each core system implemented and tested individually before integration. The architecture is intended to be clear, extensible, and easy to maintain.

## Core Features
- **Character System:** Players control a character with stats, inventory, and abilities.
- **Enemy System:** The game features enemies with their own stats and behaviors.
- **Combat System:** Turn-based combat between characters and enemies, utilizing dice rolls for randomness.
- **Item System:** Items can be found, equipped, and used by characters and enemies.
- **Environment System:** Different environments (using the `Environment` class) affect gameplay and encounters.
- **Dice System:** All randomness (e.g., combat, loot drops) is handled by a dedicated dice class.
- **Game Loop:** A main game class orchestrates the flow, user input, and system interactions.

## Implemented Classes
- `Character`: Represents the player or other characters, with stats, inventory, and equipment slots.
- `Enemy`: Represents adversaries in the game, inheriting from Character.
- `Item`: Represents items that can be used or equipped, with subclasses for weapons and armor.
- `Dice`: Handles all random number generation and dice rolls.
- `Combat`: Manages combat logic, turn order, and action execution.
- `Environment`: Represents different locations or scenarios, including room effects and enemy spawns.
- `Dungeon`: Procedurally generates a sequence of themed rooms and manages dungeon-level progression.
- `Game`: Orchestrates the main game loop, player progression, dungeon flow, inventory, and gear management.
- `Action`: Represents actions (attacks, spells, buffs, etc.) that entities can perform, with support for cooldowns and targeting.
- `Program`: The main entry point for the application, providing test harnesses, launching the game loop, and handling user startup.

## Supporting/Utility Classes
- `Entity`: Abstract base class for all actors (characters, enemies, environments) with action pools and selection logic.
- `ManageGear`: Handles gear management UI and logic, allowing players to equip/unequip items and manage inventory.
- `FlavorText`: Provides procedural generation of names and descriptions for characters, items, environments, and actions.

## Development Approach
- **Layer-by-layer:** Each system is built and tested before moving to the next.
- **Test-driven:** Unit tests are planned for each class and function, but currently no active test files are present in the codebase.
- **Documentation:** All code and systems are documented for clarity and ease of use.

## Graphical User Interface (GUI)
A simple desktop GUI is being planned and scaffolded to provide a modern, user-friendly way to interact with the game. The GUI features:
- **Fighter Stats Panel:** Displays player stats (level, XP, HP, MP, STR, SPD).
- **Event Log Panel:** Shows a scrollable log of game events.
- **Equipment Panel:** Allows equipping/unequipping items and shows inventory in a grid.
- **Dungeons Panel:** Lists available dungeons, their difficulty, and a progress bar for dungeon exploration.
- **Dark Theme:** Modern look with yellow highlights for headers and a grid-based layout.

The GUI will be implemented using WinForms or WPF and will be connected to the core game logic. (Currently in planning/scaffolding stage.)

---

## Action Combo System

The game features a dynamic Action Combo System, inspired by classic RPGs and fighting games. This system allows players to chain together a sequence of actions during combat, with each successful action amplifying the next.

### Actions
- **Taunt**: No damage, increases chance for combos, and applies a debuff to the enemy.
- **Jab**: Moderate damage, interrupts enemy combos.
- **Stun**: High damage, stuns and weakens the enemy.
- **Crit**: Massive damage, applies bleed.

Each action has:
- **Damage**: Expressed as a percentage (e.g., 150%).
- **Length**: Duration or speed modifier (e.g., 0.5x, 2x).
- **Description**: Special effects or mechanics (e.g., weaken, bleed, speed up next action).

### Performing Actions
- On your turn, you attempt the next action in the combo sequence (Taunt → Jab → Stun → Crit).
- Roll `1d20 + x` (where `x` is your bonus from loot or effects).
- If the result is **15 or higher**, the action succeeds and you move to the next action in the sequence.
- Each successful combo action amplifies the damage by **1.85x** (per step).
- If you fail, the sequence resets to Taunt.

### Loot and Bonuses
- Players can acquire loot that grants bonuses to their action rolls (e.g., +1 to the roll).
- These bonuses increase the chance of successfully chaining combos.

This system adds depth and excitement to combat, rewarding skillful play and strategic use of loot and abilities.

---

*This file will be updated as new features and layers are added.* 