using System;
using System.Collections.Generic;
using System.Linq;

namespace RPGGame
{
    public enum PassiveEffectType
    {
        None,
        DamageMultiplier, // e.g., -10% damage
        SpeedMultiplier   // e.g., +25% attack speed
    }

    public class Environment : Entity
    {
        public string Description { get; private set; }
        public bool IsHostile { get; private set; }
        private List<Enemy> enemies;
        private Random random;
        public string Theme { get; private set; }

        // Passive and active effect support
        public PassiveEffectType PassiveEffectType { get; private set; } = PassiveEffectType.None;
        public double PassiveEffectValue { get; private set; } = 1.0;
        public Action? ActiveEffectAction { get; private set; }

        public Environment(string name, string description, bool isHostile, string theme)
            : base(name)
        {
            random = new Random();
            Description = description;
            IsHostile = isHostile;
            Theme = theme;
            enemies = new List<Enemy>();
            InitializeActions();
        }

        private void InitializeActions()
        {
            bool hasAction = false;
            // Theme-specific passive/active effects and actions
            switch (Theme)
            {
                case "Forest":
                    var poisonSpores = new Action(
                        name: "Poison Spores",
                        description: "Clouds of toxic spores fill the air!",
                        type: ActionType.Debuff,
                        targetType: TargetType.AreaOfEffect,
                        baseValue: 4,
                        cooldown: 3
                    );
                    AddAction(poisonSpores, 0.7);
                    hasAction = true;
                    break;
                case "Lava":
                    var lavaOverflow = new Action(
                        name: "Lava Overflow",
                        description: "Lava surges, burning all combatants!",
                        type: ActionType.Attack,
                        targetType: TargetType.AreaOfEffect,
                        baseValue: 10,
                        cooldown: 3
                    );
                    AddAction(lavaOverflow, 0.7);
                    hasAction = true;
                    break;
                case "Crypt":
                    var hauntingWail = new Action(
                        name: "Haunting Wail",
                        description: "A ghostly wail chills you to the bone!",
                        type: ActionType.Debuff,
                        targetType: TargetType.AreaOfEffect,
                        baseValue: 5,
                        cooldown: 3
                    );
                    AddAction(hauntingWail, 0.7);
                    hasAction = true;
                    break;
                // Add more themes as needed
            }
            // Fallback to default if no theme action
            if (!hasAction)
            {
                var defaultAction = new Action(
                    name: "Environmental Hazard",
                    description: "The environment itself poses a threat!",
                    type: ActionType.Attack,
                    targetType: TargetType.AreaOfEffect,
                    baseValue: 5,
                    cooldown: 2
                );
                AddAction(defaultAction, 1.0);
            }
        }

        public void GenerateEnemies(int roomLevel)
        {
            if (!IsHostile) return;

            int enemyCount = Math.Max(1, (int)Math.Ceiling(roomLevel / 2.0));
            string[] enemyTypes = Theme switch
            {
                "Forest" => new[] { "Goblin", "Bandit", "Spider" },
                "Lava" => new[] { "Wraith", "Slime", "Bat" },
                "Crypt" => new[] { "Skeleton", "Zombie", "Wraith" },
                "Cavern" => new[] { "Orc", "Bat", "Slime" },
                "Swamp" => new[] { "Slime", "Spider", "Cultist" },
                "Desert" => new[] { "Bandit", "Cultist", "Wraith" },
                "Ice" => new[] { "Wraith", "Skeleton", "Bat" },
                "Ruins" => new[] { "Cultist", "Skeleton", "Bandit" },
                "Castle" => new[] { "Bandit", "Cultist", "Wraith" },
                "Graveyard" => new[] { "Zombie", "Wraith", "Skeleton" },
                _ => new[] { "Goblin", "Orc", "Skeleton", "Bandit", "Cultist", "Spider", "Slime", "Bat", "Zombie", "Wraith" }
            };
            for (int i = 0; i < enemyCount; i++)
            {
                int enemyLevel = Math.Max(1, roomLevel + random.Next(-1, 2));
                string type = enemyTypes[random.Next(enemyTypes.Length)];
                var enemy = new Enemy($"{type} Lv{enemyLevel}", enemyLevel);
                enemies.Add(enemy);
            }
        }

        public bool HasLivingEnemies()
        {
            return enemies.Any(e => e.IsAlive);
        }

        public Enemy? GetNextLivingEnemy()
        {
            return enemies.FirstOrDefault(e => e.IsAlive);
        }

        public bool ShouldEnvironmentAct()
        {
            return IsHostile && random.NextDouble() < 0.3; // 30% chance to act
        }

        public override string GetDescription()
        {
            string enemyInfo = "";
            if (enemies.Any())
            {
                var livingEnemies = enemies.Count(e => e.IsAlive);
                enemyInfo = $"\nThere are {livingEnemies} enemies present.";
            }
            return $"{Description}{enemyInfo}";
        }

        public override string ToString()
        {
            return $"{Name}: {GetDescription()}";
        }

        // Methods to apply passive and active effects
        public double ApplyPassiveEffect(double value)
        {
            if (PassiveEffectType == PassiveEffectType.DamageMultiplier)
                return value * PassiveEffectValue;
            return value;
        }

        public void ApplyActiveEffect(Character player, Enemy enemy)
        {
            if (ActiveEffectAction != null)
            {
                int dmg = ActiveEffectAction.BaseValue;
                player.TakeDamage(dmg);
                enemy.TakeDamage(dmg);
            }
        }
    }
} 