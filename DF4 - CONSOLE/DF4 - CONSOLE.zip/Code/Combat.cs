namespace RPGGame
{
    public class Combat
    {
        /// <summary>
        /// Executes a combat action from the source entity to the target entity.
        /// </summary>
        /// <param name="source">The entity performing the action</param>
        /// <param name="target">The entity receiving the action</param>
        /// <param name="environment">The environment affecting the action</param>
        /// <returns>A string describing the result of the action</returns>
        public static string ExecuteAction(Entity source, Entity target, Environment? environment = null)
        {
            // Only run combo logic for the player (not for enemies or other entities)
            if (source is Character player && !(player is Enemy))
            {
                player.UpdateComboBonus();
                var comboActions = player.GetComboActions();
                if (comboActions.Count == 0)
                {
                    string msg = "No combo actions available.";
                    System.Threading.Thread.Sleep(400);
                    return msg;
                }
                var action = comboActions[player.ComboStep % comboActions.Count];
                int rollBonus = player.ComboBonus;
                int tempBonus = player.ConsumeTempComboBonus();
                int roll = Dice.Roll(20) + rollBonus + tempBonus;
                string rollMsg = $"(Rolled {roll - rollBonus - tempBonus} + {rollBonus} + {tempBonus} = {roll}, need {comboThreshold})";
                if (roll >= comboThreshold)
                {
                    // Combo amplifier is now ^comboStepExponent per step
                    player.ComboAmplifier = Math.Pow(comboStepExponent, player.ComboStep);
                    int baseEffect = action.BaseValue > 0 ? action.BaseValue : 1;
                    double effect = baseEffect * action.DamageMultiplier * player.ComboAmplifier;
                    double effectBeforeEnv = effect;
                    string envMsg = "";
                    if (environment != null)
                    {
                        effect = environment.ApplyPassiveEffect(effect);
                        if (effect != effectBeforeEnv && environment.PassiveEffectType != PassiveEffectType.None)
                        {
                            envMsg = $" (Environment passive: {environment.PassiveEffectType} applied, final value: {effect:0.##})";
                        }
                    }
                    int finalEffect = (int)effect;
                    string result = $"[Player] uses [{action.Name}] on [{target.Name}]: ";
                    if (action.Type == ActionType.Attack)
                    {
                        // Get weapon damage
                        int weaponDamage = 0;
                        if (player.Weapon is WeaponItem weapon)
                            weaponDamage = weapon.Damage;
                        // Get target armor
                        int armor = 0;
                        if (target is Character targetChar)
                        {
                            if (targetChar.Head is HeadItem head) armor += head.Armor;
                            if (targetChar.Body is ChestItem body) armor += body.Armor;
                            if (targetChar.Feet is FeetItem feet) armor += feet.Armor;
                        }
                        int strength = player.Strength;
                        double raw = (weaponDamage + strength) * action.DamageMultiplier * player.ComboAmplifier;
                        finalEffect = Math.Max(0, (int)raw - armor);
                        if (target is Character c) c.TakeDamage(finalEffect);
                        result += $"deals {finalEffect} damage (raw: {raw:0.##}, armor: {armor}){envMsg}.";
                    }
                    else if (action.Type == ActionType.Debuff)
                    {
                        // If this debuff also does damage (e.g., Stun), apply damage
                        if (action.DamageMultiplier > 0)
                        {
                            int weaponDamage = 0;
                            if (player.Weapon is WeaponItem weapon)
                                weaponDamage = weapon.Damage;
                            int armor = 0;
                            if (target is Character targetChar)
                            {
                                if (targetChar.Head is HeadItem head) armor += head.Armor;
                                if (targetChar.Body is ChestItem body) armor += body.Armor;
                                if (targetChar.Feet is FeetItem feet) armor += feet.Armor;
                            }
                            int strength = player.Strength;
                            double raw = (weaponDamage + strength) * action.DamageMultiplier * player.ComboAmplifier;
                            finalEffect = Math.Max(0, (int)raw - armor);
                            if (target is Character c) c.TakeDamage(finalEffect);
                            result += $"deals {finalEffect} damage (raw: {raw:0.##}, armor: {armor}). ";
                        }
                        result += $"applies debuff.";
                        if (action.ComboBonusAmount > 0 && action.ComboBonusDuration > 0)
                        {
                            player.SetTempComboBonus(action.ComboBonusAmount, action.ComboBonusDuration);
                            result += $" ({action.Name}: +{action.ComboBonusAmount} to next {action.ComboBonusDuration} combo rolls!)";
                        }
                    }
                    if (action.CausesBleed)
                        result += " (Bleed effect applied!)";
                    if (action.CausesWeaken)
                        result += " (Weaken effect applied!)";
                    result += $" {rollMsg}";
                    player.ComboStep++;
                    if (player.ComboStep >= comboActions.Count)
                    {
                        result += " Combo complete! Resetting combo.";
                        player.ComboStep = 0;
                        player.ComboAmplifier = 1.0;
                    }
                    return result;
                }
                else
                {
                    string failMsg = $"[{player.Name}] uses [{action.Name}] but fails. {rollMsg} No action performed. Combo resets.";
                    System.Threading.Thread.Sleep(400);
                    return failMsg;
                }
            }
            // Regular action logic for enemies and other entities
            var selectedAction = source.SelectAction();
            if (selectedAction == null)
                return $"{source.Name} has no available actions!";
            if (selectedAction.IsOnCooldown)
            {
                selectedAction.UpdateCooldown();
                return $"{source.Name}'s {selectedAction.Name} is on cooldown! ({selectedAction.CurrentCooldown} turns remaining)";
            }
            double selectedEffect = 0;
            double effectBeforeEnv2 = 0;
            string envMsg2 = "";
            if (source is Character sourceCharacter)
            {
                selectedEffect = selectedAction.CalculateEffect(sourceCharacter, target as Character);
                effectBeforeEnv2 = selectedEffect;
                if (environment != null)
                {
                    selectedEffect = environment.ApplyPassiveEffect(selectedEffect);
                    if (selectedEffect != effectBeforeEnv2 && environment.PassiveEffectType != PassiveEffectType.None)
                    {
                        envMsg2 = $" (Environment passive: {environment.PassiveEffectType} applied, final value: {selectedEffect:0.##})";
                    }
                }
            }
            else
            {
                return $"{source.Name} is not a valid character for this action!";
            }
            string selectedResult = $"[{source.Name}] uses [{selectedAction.Name}] on [{target.Name}]: ";
            switch (selectedAction.Type)
            {
                case ActionType.Attack:
                    if (target is Character character)
                    {
                        character.TakeDamage((int)selectedEffect);
                        selectedResult += $"deals {(int)selectedEffect} damage{envMsg2}.";
                    }
                    break;
                case ActionType.Heal:
                    if (target is Character healTarget)
                    {
                        healTarget.Heal((int)selectedEffect);
                        selectedResult += $"heals {(int)selectedEffect} HP.";
                    }
                    break;
                case ActionType.Buff:
                    selectedResult += $"applies buff.";
                    break;
                case ActionType.Debuff:
                    selectedResult += $"applies debuff.";
                    break;
                case ActionType.Interact:
                    selectedResult += $"interacts with environment.";
                    break;
                case ActionType.Move:
                    selectedResult += $"moves.";
                    break;
                case ActionType.UseItem:
                    selectedResult += $"uses item.";
                    break;
                default:
                    selectedResult += $"performs action.";
                    break;
            }
            if (selectedAction.Cooldown > 0)
                selectedAction.ResetCooldown();
            return selectedResult;
        }

        private static string ApplyEffect(Action action, Entity source, Entity target, int effect)
        {
            switch (action.Type)
            {
                case ActionType.Attack:
                    if (target is Character character)
                    {
                        character.TakeDamage(effect);
                        return $"{source.Name} used {action.Name} on {target.Name} for {effect} damage!";
                    }
                    break;

                case ActionType.Heal:
                    if (target is Character healTarget)
                    {
                        healTarget.Heal(effect);
                        return $"{source.Name} used {action.Name} on {target.Name} to heal {effect} health!";
                    }
                    break;

                case ActionType.Buff:
                    // Buff effects would be implemented here
                    return $"{source.Name} used {action.Name} on {target.Name} to apply a buff!";

                case ActionType.Debuff:
                    // Debuff effects would be implemented here
                    return $"{source.Name} used {action.Name} on {target.Name} to apply a debuff!";

                case ActionType.Interact:
                    return $"{source.Name} used {action.Name} to interact with {target.Name}!";

                case ActionType.Move:
                    return $"{source.Name} used {action.Name} to move!";

                case ActionType.UseItem:
                    return $"{source.Name} used {action.Name} to use an item!";
            }

            return $"{source.Name} used {action.Name} on {target.Name}!";
        }

        // Combo state tracking (for demo: static, but should be per-character in a full implementation)
        // private static int playerComboStep = 0;
        // private static double playerComboAmplifier = 1.0;
        // private static int playerComboBonus = 0; // TODO: Add loot integration
        private static readonly int comboThreshold = 10;
        public static double comboStepExponent = 0.85; // Adjustable combo step exponent
        //public static double comboStepExponent = 1.15; // Adjustable combo step exponent
    }
} 