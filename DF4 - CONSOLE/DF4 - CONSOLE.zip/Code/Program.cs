﻿using System;
using RPGGame;

namespace RPGGame
{
    class Program
    {
        static void TestCharacterLeveling()
        {
            var character = new Character();

            Console.WriteLine("Initial Character Stats:");
            Console.WriteLine($"Level: {character.Level}");
            Console.WriteLine($"XP: {character.XP}");
            Console.WriteLine($"Strength: {character.Strength}");
            Console.WriteLine($"Agility: {character.Agility}");
            Console.WriteLine($"Technique: {character.Technique}");
            Console.WriteLine($"Health: {character.CurrentHealth}/{character.MaxHealth}");

            character.AddXP(100);
            Console.WriteLine("\nAfter Leveling Up:");
            Console.WriteLine($"Level: {character.Level}");
            Console.WriteLine($"XP: {character.XP}");
            Console.WriteLine($"Strength: {character.Strength}");
            Console.WriteLine($"Agility: {character.Agility}");
            Console.WriteLine($"Technique: {character.Technique}");
            Console.WriteLine($"Health: {character.CurrentHealth}/{character.MaxHealth}");
        }

        static void TestItems()
        {
            var helmet = new HeadItem("Helmet", 100, 5, 2.5);
            var boots = new FeetItem("Boots", 80, 2, 1.2);
            var armor = new ChestItem("Armor", 150, 10, 8.0);
            var sword = new WeaponItem("Sword", 200, 15, 4.0);

            Console.WriteLine("\nHead Item:");
            Console.WriteLine($"  Name: {helmet.Name}, Type: {helmet.Type}, Durability: {helmet.Durability}, Armor: {helmet.Armor}, Weight: {helmet.Weight}");

            Console.WriteLine("Feet Item:");
            Console.WriteLine($"  Name: {boots.Name}, Type: {boots.Type}, Durability: {boots.Durability}, Armor: {boots.Armor}, Weight: {boots.Weight}");

            Console.WriteLine("Chest Item:");
            Console.WriteLine($"  Name: {armor.Name}, Type: {armor.Type}, Durability: {armor.Durability}, Armor: {armor.Armor}, Weight: {armor.Weight}");

            Console.WriteLine("Weapon Item:");
            Console.WriteLine($"  Name: {sword.Name}, Type: {sword.Type}, Durability: {sword.Durability}, Damage: {sword.Damage}, Weight: {sword.Weight}");
        }

        static void TestDice()
        {
            Console.WriteLine("\nTesting Dice Rolls:");
            Console.WriteLine($"1d6: {Dice.Roll(6)}");
            Console.WriteLine($"2d6: {Dice.Roll(2, 6)}");
            Console.WriteLine($"1d20: {Dice.Roll(20)}");
            Console.WriteLine($"3d8: {Dice.Roll(3, 8)}");
        }

        static void TestActions()
        {
            Console.WriteLine("\nTesting Actions:");
            
            // Create a character to test with
            var character = new Character();
            Console.WriteLine($"Testing with character - Strength: {character.Strength}, Technique: {character.Technique}");

            // Create different types of actions
            var basicAttack = new Action(
                "Basic Attack",
                ActionType.Attack,
                TargetType.SingleTarget,
                baseValue: 5,
                range: 1,
                description: "A basic melee attack"
            );

            var fireball = new Action(
                "Fireball",
                ActionType.Attack,
                TargetType.AreaOfEffect,
                baseValue: 8,
                range: 3,
                cooldown: 2,
                description: "Hurl a ball of fire at your enemies"
            );

            var heal = new Action(
                "Heal",
                ActionType.Heal,
                TargetType.SingleTarget,
                baseValue: 10,
                range: 2,
                cooldown: 3,
                description: "Restore health to a target"
            );

            // Display action information
            Console.WriteLine("\nAction Details:");
            Console.WriteLine($"1. {basicAttack}");
            Console.WriteLine($"2. {fireball}");
            Console.WriteLine($"3. {heal}");

            // Test effect calculations
            Console.WriteLine("\nEffect Calculations:");
            Console.WriteLine($"Basic Attack damage: {basicAttack.CalculateEffect(character)}");
            Console.WriteLine($"Fireball damage: {fireball.CalculateEffect(character)}");
            Console.WriteLine($"Heal amount: {heal.CalculateEffect(character)}");

            // Test cooldown system
            Console.WriteLine("\nCooldown Testing:");
            Console.WriteLine($"Fireball initial cooldown: {fireball.CurrentCooldown}");
            fireball.ResetCooldown();
            Console.WriteLine($"Fireball after reset: {fireball.CurrentCooldown}");
            Console.WriteLine($"Is Fireball on cooldown? {fireball.IsOnCooldown}");
            
            // Simulate turns passing
            Console.WriteLine("\nSimulating turns:");
            for (int i = 1; i <= 3; i++)
            {
                fireball.UpdateCooldown();
                Console.WriteLine($"Turn {i}: Fireball cooldown = {fireball.CurrentCooldown}");
            }

            // Test different target types
            Console.WriteLine("\nTarget Types:");
            var selfBuff = new Action(
                "Self Buff",
                ActionType.Buff,
                TargetType.Self,
                baseValue: 5,
                description: "Increase your own stats"
            );

            var environmentAction = new Action(
                "Search",
                ActionType.Interact,
                TargetType.Environment,
                baseValue: 0,
                description: "Search the environment"
            );

            Console.WriteLine($"Self-targeting action: {selfBuff}");
            Console.WriteLine($"Environment action: {environmentAction}");
        }

        static void TestEntityActionPools()
        {
            Console.WriteLine("\nTesting Entity Action Pools:");

            // Create test entities
            var character = new Character("Test Hero");
            var weakEnemy = new Enemy("Goblin", 1, 30, 5, 10);
            var strongEnemy = new Enemy("Orc Warlord", 5, 100, 50, 100);
            var friendlyEnvironment = new Environment("Forest Clearing", "A peaceful clearing in the woods", false, "Forest");
            var hostileEnvironment = new Environment("Lava Pit", "A dangerous pool of molten lava", true, "Lava");

            // Test Character Action Pool
            Console.WriteLine("\nCharacter Action Pool:");
            Console.WriteLine(character);
            Console.WriteLine($"Attributes - STR: {character.Strength}, AGI: {character.Agility}, TEC: {character.Technique}");
            Console.WriteLine("Available Actions:");
            for (int i = 0; i < 5; i++)
            {
                var action = character.SelectAction();
                Console.WriteLine($"  Selected: {action?.Name} (Type: {action?.Type})");
            }

            // Test Weak Enemy Action Pool
            Console.WriteLine("\nWeak Enemy Action Pool:");
            Console.WriteLine(weakEnemy);
            Console.WriteLine($"Attributes - STR: {weakEnemy.Strength}, AGI: {weakEnemy.Agility}, TEC: {weakEnemy.Technique}");
            Console.WriteLine("Available Actions:");
            for (int i = 0; i < 5; i++)
            {
                var action = weakEnemy.SelectAction();
                Console.WriteLine($"  Selected: {action?.Name} (Type: {action?.Type})");
            }

            // Test Strong Enemy Action Pool
            Console.WriteLine("\nStrong Enemy Action Pool:");
            Console.WriteLine(strongEnemy);
            Console.WriteLine($"Attributes - STR: {strongEnemy.Strength}, AGI: {strongEnemy.Agility}, TEC: {strongEnemy.Technique}");
            Console.WriteLine("Available Actions:");
            for (int i = 0; i < 5; i++)
            {
                var action = strongEnemy.SelectAction();
                Console.WriteLine($"  Selected: {action?.Name} (Type: {action?.Type})");
            }

            // Test Environment Action Pools
            Console.WriteLine("\nEnvironment Action Pools:");
            Console.WriteLine("Friendly Environment:");
            Console.WriteLine(friendlyEnvironment);
            Console.WriteLine("Available Actions:");
            for (int i = 0; i < 5; i++)
            {
                var action = friendlyEnvironment.SelectAction();
                Console.WriteLine($"  Selected: {action?.Name} (Type: {action?.Type})");
            }

            Console.WriteLine("\nHostile Environment:");
            Console.WriteLine(hostileEnvironment);
            Console.WriteLine("Available Actions:");
            for (int i = 0; i < 5; i++)
            {
                var action = hostileEnvironment.SelectAction();
                Console.WriteLine($"  Selected: {action?.Name} (Type: {action?.Type})");
            }

            // Test Character vs Enemy Interaction
            Console.WriteLine("\nTesting Character vs Enemy Interaction:");
            Console.WriteLine("Character attacks Enemy:");
            var attackAction = character.SelectAction();
            if (attackAction != null)
            {
                int damage = attackAction.CalculateEffect(character);
                weakEnemy.TakeDamage(damage);
                Console.WriteLine($"Character used {attackAction.Name} for {damage} damage");
                Console.WriteLine($"Enemy health: {weakEnemy.CurrentHealth}/{weakEnemy.MaxHealth}");
            }

            Console.WriteLine("\nEnemy counterattacks:");
            var enemyAction = weakEnemy.SelectAction();
            if (enemyAction != null)
            {
                int enemyDamage = enemyAction.CalculateEffect(weakEnemy);
                character.TakeDamage(enemyDamage);
                Console.WriteLine($"Enemy used {enemyAction.Name} for {enemyDamage} damage");
                Console.WriteLine($"Character health: {character.CurrentHealth}/{character.MaxHealth}");
            }

            // Test Level Scaling
            Console.WriteLine("\nTesting Enemy Level Scaling:");
            Console.WriteLine("Level 1 Enemy vs Level 5 Enemy Attributes:");
            Console.WriteLine($"Level 1 - STR: {weakEnemy.Strength}, AGI: {weakEnemy.Agility}, TEC: {weakEnemy.Technique}");
            Console.WriteLine($"Level 5 - STR: {strongEnemy.Strength}, AGI: {strongEnemy.Agility}, TEC: {strongEnemy.Technique}");
        }

        static void TestCombat()
        {
            Console.WriteLine("\nTesting Combat System:");
            
            // Create test characters
            var hero = new Character("Hero", 1);
            var enemy = new Character("Enemy", 1);

            // Add some actions to the hero
            var basicAttack = new Action("Basic Attack", ActionType.Attack, TargetType.SingleTarget, 5, 1);
            var heal = new Action("Heal", ActionType.Heal, TargetType.SingleTarget, 10, 1, 2);
            hero.AddAction(basicAttack, 0.7); // 70% chance to select basic attack
            hero.AddAction(heal, 0.3); // 30% chance to select heal

            // Add some actions to the enemy
            var enemyAttack = new Action("Enemy Attack", ActionType.Attack, TargetType.SingleTarget, 3, 1);
            enemy.AddAction(enemyAttack, 1.0); // 100% chance to select attack

            Console.WriteLine("Initial States:");
            Console.WriteLine($"Hero Health: {hero.CurrentHealth}/{hero.MaxHealth}");
            Console.WriteLine($"Enemy Health: {enemy.CurrentHealth}/{enemy.MaxHealth}");

            // Test basic attack
            Console.WriteLine("\nTesting Basic Attack:");
            string result = Combat.ExecuteAction(hero, enemy);
            Console.WriteLine(result);
            Console.WriteLine($"Enemy Health: {enemy.CurrentHealth}/{enemy.MaxHealth}");

            // Test enemy counterattack
            Console.WriteLine("\nTesting Enemy Counterattack:");
            result = Combat.ExecuteAction(enemy, hero);
            Console.WriteLine(result);
            Console.WriteLine($"Hero Health: {hero.CurrentHealth}/{hero.MaxHealth}");

            // Test healing
            Console.WriteLine("\nTesting Healing:");
            result = Combat.ExecuteAction(hero, hero); // Self-heal
            Console.WriteLine(result);
            Console.WriteLine($"Hero Health: {hero.CurrentHealth}/{hero.MaxHealth}");

            // Test cooldown system
            Console.WriteLine("\nTesting Cooldown System:");
            result = Combat.ExecuteAction(hero, hero); // Try to heal again
            Console.WriteLine(result);

            // Test with no available actions
            Console.WriteLine("\nTesting No Available Actions:");
            var emptyCharacter = new Character("Empty", 1);
            result = Combat.ExecuteAction(emptyCharacter, hero);
            Console.WriteLine(result);
        }

        static void RunGame()
        {
            Console.WriteLine("\n1. Start New Game");
            Console.WriteLine("2. Exit\n");
            Console.Write("Choose an option: ");

            string? choice = Console.ReadLine();
            if (choice == "1")
            {
                var game = new Game();
                game.Run();
                return;
            }
            else
            {
                Console.WriteLine("\nGoodbye!\n");
                return;
            }
        }

        static void RunTests()
        {
            Console.WriteLine("Running Tests...\n");

            Console.WriteLine("1. Character Leveling Test");
            TestCharacterLeveling();
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();

            Console.WriteLine("\n2. Items Test");
            TestItems();
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();

            Console.WriteLine("\n3. Dice Test");
            TestDice();
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();

            Console.WriteLine("\n4. Actions Test");
            TestActions();
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();

            Console.WriteLine("\n5. Entity Action Pools Test");
            TestEntityActionPools();
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();

            Console.WriteLine("\n6. Combat Test");
            TestCombat();
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }

        static void Main(string[] args)
        {
            Console.WriteLine("\nDungeon Crawler - Main Menu\n");
            Console.WriteLine("1. Play Game");
            Console.WriteLine("2. Run Tests");
            Console.WriteLine("3. Exit\n");
            Console.Write("Choose an option: ");

            string? choice = Console.ReadLine();
            switch (choice)
            {
                case "1":
                    RunGame();
                    break;
                case "2":
                    RunTests();
                    break;
                case "3":
                    Console.WriteLine("Goodbye!");
                    break;
                default:
                    Console.WriteLine("Invalid choice. Exiting...");
                    break;
            }
            Console.WriteLine("\n");
        }
    }
} 