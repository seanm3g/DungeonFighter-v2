namespace RPGGame
{
    using System.Threading;

    public class Game
    {
        private Character player;
        private List<Item> inventory;
        private List<Dungeon> availableDungeons;
        private Random random;

        public Game()
        {
            random = new Random();
            inventory = new List<Item>();
            availableDungeons = new List<Dungeon>();
            player = new Character();
            InitializeGame();
        }

        private void InitializeGame()
        {
            // Prompt player to choose a starter weapon
            Console.WriteLine();
            Console.WriteLine("Choose your starter weapon:");
            Console.WriteLine("1. Sword");
            Console.WriteLine("2. Axe");
            Console.WriteLine("3. Dagger");
            Console.WriteLine();
            int weaponChoice = 1;
            while (true)
            {
                Console.Write("Choose an option: ");
                if (int.TryParse(Console.ReadLine(), out weaponChoice) && weaponChoice >= 1 && weaponChoice <= 3)
                    break;
                Console.WriteLine("Invalid choice.");
            }
            WeaponItem starterWeapon;
            switch (weaponChoice)
            {
                case 1:
                    starterWeapon = new WeaponItem("Starter Sword", 100, 5, 2.0);
                    break;
                case 2:
                    starterWeapon = new WeaponItem("Starter Axe", 100, 7, 3.0);
                    break;
                case 3:
                    starterWeapon = new WeaponItem("Starter Dagger", 100, 3, 1.0);
                    break;
                default:
                    starterWeapon = new WeaponItem("Starter Sword", 100, 5, 2.0);
                    break;
            }
            var leatherHelmet = new HeadItem("Leather Helmet", 100, 2, 1.0);
            var leatherArmor = new ChestItem("Leather Armor", 100, 4, 3.0);
            var leatherBoots = new FeetItem("Leather Boots", 100, 1, 1.0);
            player.EquipItem(starterWeapon, "weapon");
            player.EquipItem(leatherHelmet, "head");
            player.EquipItem(leatherArmor, "body");
            player.EquipItem(leatherBoots, "feet");

            // Themed dungeons
            availableDungeons.Clear();
            int playerLevel = player.Level;
            int[] dungeonLevels = new int[] { Math.Max(1, playerLevel - 1), playerLevel, playerLevel + 1 };
            string[] themes = new[] { "Forest", "Lava", "Crypt", "Cavern", "Swamp", "Desert", "Ice", "Ruins", "Castle", "Graveyard" };
            for (int i = 0; i < dungeonLevels.Length; i++)
            {
                string theme = themes[random.Next(themes.Length)];
                string themedName = $"{theme} Dungeon (Level {dungeonLevels[i]})";
                availableDungeons.Add(new Dungeon(themedName, dungeonLevels[i], dungeonLevels[i], theme));
            }
        }

        public void Run()
        {
            Console.WriteLine("\nWelcome to the Dungeon Crawler!\n");
            Console.WriteLine($"Player: {player.Name} (Level {player.Level})");

            while (true)
            {
                // Ask if player wants to manage gear first
                Console.WriteLine("\nWhat would you like to do?");
                Console.WriteLine();
                Console.WriteLine("1. Inventory");
                Console.WriteLine("2. Choose a Dungeon");
                Console.WriteLine("3. Exit Game\n");
                Console.Write("Enter your choice: ");

                if (int.TryParse(Console.ReadLine(), out int initialChoice))
                {
                    switch (initialChoice)
                    {
                        case 1:
                            var inventoryManager = new Inventory(player, inventory);
                            inventoryManager.ShowGearMenu();
                            // Fall through to dungeon selection
                            break;
                        case 2:
                            // Go straight to dungeon selection
                            break;
                        case 3:
                            Console.WriteLine("Thanks for playing!");
                            return;
                        default:
                            Console.WriteLine("Invalid choice. Exiting game.");
                            return;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Exiting game.");
                    return;
                }

                // Always regenerate dungeons based on current player level
                availableDungeons.Clear();
                int playerLevel = player.Level;
                int[] dungeonLevels = new int[] { Math.Max(1, playerLevel - 1), playerLevel, playerLevel + 1 };
                string[] themes = new[] { "Forest", "Lava", "Crypt", "Cavern", "Swamp", "Desert", "Ice", "Ruins", "Castle", "Graveyard" };
                for (int i = 0; i < dungeonLevels.Length; i++)
                {
                    string theme = themes[random.Next(themes.Length)];
                    string themedName = $"{theme} Dungeon (Level {dungeonLevels[i]})";
                    availableDungeons.Add(new Dungeon(themedName, dungeonLevels[i], dungeonLevels[i], theme));
                }

                // Dungeon Selection and Run
                Dungeon selectedDungeon = ChooseDungeon();
                selectedDungeon.Generate();

                Console.WriteLine($"\nEntering {selectedDungeon.Name}...");

                // Room Sequence
                foreach (Environment room in selectedDungeon.Rooms)
                {
                    Console.WriteLine($"\nEntering room: {room.Name}");
                    Console.WriteLine(room.Description);

                    while (room.HasLivingEnemies())
                    {
                        Enemy? currentEnemy = room.GetNextLivingEnemy();
                        if (currentEnemy == null) break;

                        Console.WriteLine($"\nEncountered {currentEnemy.Name}!");
                        Console.WriteLine($"Enemy Level: {currentEnemy.Level}");

                        // Combat Loop with overlapping cooldowns
                        double playerCooldown = 0;
                        double enemyCooldown = 0;
                        double envCooldown = 0;
                        double timeUnitMs = 750; // 750ms per action time unit (slowed down by 50%)
                        while (player.IsAlive && currentEnemy.IsAlive)
                        {
                            // Find the minimum cooldown
                            double minCooldown = Math.Min(playerCooldown, Math.Min(enemyCooldown, envCooldown));
                            if (minCooldown > 0)
                            {
                                // Advance time
                                playerCooldown -= minCooldown;
                                enemyCooldown -= minCooldown;
                                envCooldown -= minCooldown;
                                Thread.Sleep((int)(minCooldown * timeUnitMs));
                            }
                            // Player acts
                            if (playerCooldown <= 0 && player.IsAlive)
                            {
                                var comboActions = player.GetComboActions();
                                int actionIdx = 0;
                                if (comboActions.Count > 0)
                                    actionIdx = player.ComboStep % comboActions.Count;
                                var attemptedAction = comboActions.Count > 0 ? comboActions[actionIdx] : null;

                                string result = Combat.ExecuteAction(player, currentEnemy, room);
                                Console.WriteLine(result);
                                // Dynamic delay based on combo step
                                int extraDelayPlayer = 200 + player.ComboStep * 500;
                                Thread.Sleep(extraDelayPlayer);
                                Console.WriteLine();
                                Console.WriteLine($"Enemy Health: {currentEnemy.CurrentHealth}/{currentEnemy.MaxHealth}");
                                // Use the attempted action's length for cooldown, regardless of ComboStep changes
                                double lastActionLength = attemptedAction != null ? attemptedAction.Length : 1.0;
                                playerCooldown = lastActionLength;
                                if (!currentEnemy.IsAlive)
                                {
                                    Console.WriteLine($"{currentEnemy.Name} has been defeated!");
                                    player.AddXP(currentEnemy.XPReward);
                                    break;
                                }
                            }
                            // Enemy acts
                            if (enemyCooldown <= 0 && currentEnemy.IsAlive)
                            {
                                // Weighted random selection for enemy action
                                var enemyAction = currentEnemy.SelectAction();
                                string result = "";
                                if (enemyAction != null)
                                {
                                    // Use the same logic as AttemptAction, but with the selected action
                                    int roll = Dice.Roll(20);
                                    if (roll >= 10)
                                    {
                                        double effect = enemyAction.BaseValue;
                                        if (room != null)
                                            effect = room.ApplyPassiveEffect(effect);
                                        int finalEffect = (int)effect;
                                        if (enemyAction.Type == ActionType.Attack)
                                        {
                                            player.TakeDamage(finalEffect);
                                            result = $"[{currentEnemy.Name}] uses [{enemyAction.Name}] on [{player.Name}]: deals {finalEffect} damage. (Rolled {roll}, need 10)";
                                        }
                                        else if (enemyAction.Type == ActionType.Debuff)
                                        {
                                            result = $"[{currentEnemy.Name}] uses [{enemyAction.Name}] on [{player.Name}]: applies debuff. (Rolled {roll}, need 10)";
                                        }
                                        else
                                        {
                                            result = $"[{currentEnemy.Name}] uses [{enemyAction.Name}] on [{player.Name}]. (Rolled {roll}, need 10)";
                                        }
                                    }
                                    else
                                    {
                                        result = $"[{currentEnemy.Name}] attempts [{enemyAction.Name}] but fails. (Rolled {roll}, need 10) No action performed.";
                                    }
                                    // Set cooldown based on the action used
                                    enemyCooldown = enemyAction.Length;
                                }
                                else
                                {
                                    result = $"{currentEnemy.Name} has no available actions!";
                                    enemyCooldown = 1.0;
                                }
                                Console.WriteLine(result);
                                // Dynamic delay based on combo step
                                int extraDelayEnemy = 200 + player.ComboStep * 500;
                                Thread.Sleep(extraDelayEnemy);
                                Console.WriteLine();
                                Console.WriteLine($"Player Health: {player.CurrentHealth}/{player.MaxHealth}");
                                if (!player.IsAlive)
                                {
                                    Console.WriteLine("You have been defeated!");
                                    return;
                                }
                            }
                            // Environment acts
                            if (envCooldown <= 0 && room.IsHostile && room.ActionPool.Count > 0)
                            {
                                var envAction = room.ActionPool[0].action;
                                string result = Combat.ExecuteAction(room, player, room);
                                if (!result.Contains("is not a valid character for this action!"))
                                {
                                    Console.WriteLine(result);
                                    // Dynamic delay based on combo step
                                    int extraDelayEnv = 200 + player.ComboStep * 500;
                                    Thread.Sleep(extraDelayEnv);
                                    Console.WriteLine();
                                    Console.WriteLine($"Player Health: {player.CurrentHealth}/{player.MaxHealth}");
                                }
                                envCooldown = envAction.Length;
                                if (!player.IsAlive)
                                {
                                    Console.WriteLine("You have been defeated by the environment!");
                                    return;
                                }
                            }
                        }
                    }

                    Console.WriteLine("Room cleared!");
                    Console.WriteLine($"Remaining Health: {player.CurrentHealth}/{player.MaxHealth}");
                }

                // Dungeon Completion
                AwardLootAndXP();
            }
        }

        private Dungeon ChooseDungeon()
        {
            Console.WriteLine("\nAvailable Dungeons:\n");
            for (int i = 0; i < availableDungeons.Count; i++)
            {
                var d = availableDungeons[i];
                Console.WriteLine($"{i + 1}. {d.Name} - Theme: {d.Theme}");
            }

            int choice = -1;
            while (choice < 1 || choice > availableDungeons.Count)
            {
                Console.Write($"\nChoose a dungeon (1-{availableDungeons.Count}): ");
                string? input = Console.ReadLine();
                if (!int.TryParse(input, out choice) || choice < 1 || choice > availableDungeons.Count)
                {
                    Console.WriteLine("Invalid choice. Please enter a valid dungeon number.");
                }
            }
            return availableDungeons[choice - 1];
        }

        private void AwardLootAndXP()
        {
            Console.WriteLine("\nDungeon completed!");
            // Determine current dungeon level
            int dungeonLevel = player.Level;
            if (availableDungeons.Count > 0)
            {
                var lastDungeon = availableDungeons.Find(d => d.Rooms.Count > 0);
                if (lastDungeon != null)
                    dungeonLevel = lastDungeon.MinLevel;
            }
            // Award random item, stats scale with dungeon level
            ItemType randomType = (ItemType)random.Next(4);
            Item reward = randomType switch
            {
                ItemType.Weapon => new WeaponItem(damage: random.Next(3, 6) + dungeonLevel * 2),
                ItemType.Head => new HeadItem(armor: random.Next(1, 3) + dungeonLevel),
                ItemType.Chest => new ChestItem(armor: random.Next(2, 5) + dungeonLevel * 2),
                ItemType.Feet => new FeetItem(armor: random.Next(1, 2) + dungeonLevel),
                _ => throw new InvalidOperationException()
            };

            // Add to both inventories
            player.AddToInventory(reward);
            inventory.Add(reward);
            Console.WriteLine($"You found: {reward.Name}");

            // Award XP (scaled by dungeon level)
            int xpReward = random.Next(50, 100) * player.Level;
            player.AddXP(xpReward);
            Console.WriteLine($"Gained {xpReward} XP!");

            if (player.Level > 1)
            {
                Console.WriteLine($"Level up! You are now level {player.Level}");
            }
        }
    }

    public class Dungeon
    {
        public string Name { get; private set; }
        public int MinLevel { get; private set; }
        public int MaxLevel { get; private set; }
        public string Theme { get; private set; }
        public List<Environment> Rooms { get; private set; }
        private Random random;

        public Dungeon(string name, int minLevel, int maxLevel, string theme)
        {
            random = new Random();
            Name = name;
            MinLevel = minLevel;
            MaxLevel = maxLevel;
            Theme = theme;
            Rooms = new List<Environment>();
        }

        public void Generate()
        {
            int roomCount = Math.Max(1, (int)Math.Ceiling(MinLevel / 2.0) + 0); // 1 room at level 1, scales up
            Rooms.Clear();

            for (int i = 0; i < roomCount; i++)
            {
                // Determine room type and difficulty
                bool isHostile = random.NextDouble() < 0.8; // 80% chance of hostile room
                int roomLevel = random.Next(MinLevel, MaxLevel + 1);

                // Create room with appropriate theme
                string roomTheme = GetRoomTheme(i, roomCount);
                string? desc = GetRoomDescription(roomTheme, isHostile);
                string roomDesc = desc ?? "A mysterious room with an unknown purpose.";
                var room = new Environment(
                    name: $"{roomTheme} Room",
                    description: roomDesc,
                    isHostile: isHostile,
                    theme: Theme
                );

                // Generate enemies with scaled levels
                room.GenerateEnemies(roomLevel);
                Rooms.Add(room);
            }
        }

        private string GetRoomTheme(int roomIndex, int totalRooms)
        {
            if (roomIndex == 0) return "Entrance";
            if (roomIndex == totalRooms - 1) return "Boss";

            string[] themes = new[]
            {
                "Treasure", "Guard", "Trap", "Puzzle", "Rest",
                "Storage", "Library", "Armory", "Kitchen", "Dining"
            };

            return themes[random.Next(themes.Length)];
        }

        private string? GetRoomDescription(string theme, bool isHostile)
        {
            return theme switch
            {
                "Entrance" => "A large, imposing entrance to the dungeon. The air is thick with anticipation.",
                "Boss" => "A grand chamber, clearly the domain of a powerful being. The walls are adorned with trophies of past conquests.",
                "Treasure" => "A room filled with glittering gold and precious artifacts. But is it too good to be true?",
                "Guard" => "A well-fortified position, manned by vigilant guards.",
                "Trap" => "The floor is suspiciously clean, and the walls have strange markings.",
                "Puzzle" => "Ancient mechanisms and cryptic symbols cover the walls.",
                "Rest" => "A surprisingly peaceful area, with comfortable furnishings.",
                "Storage" => "Shelves and crates line the walls, filled with supplies.",
                "Library" => "Rows of ancient tomes and scrolls fill this room.",
                "Armory" => "Weapons and armor are displayed on racks and stands.",
                "Kitchen" => "A large cooking area, with pots and pans hanging from the ceiling.",
                "Dining" => "A long table set for a feast, though the food looks... questionable.",
                _ => null
            } + (isHostile ? " Danger lurks in the shadows." : " It seems safe... for now.");
        }
    }
} 