namespace RPGGame
{
    public class Enemy : Character
    {
        public int GoldReward { get; private set; }
        public int XPReward { get; private set; }

        public Enemy(string? name = null, int level = 1, int maxHealth = 50, int strength = 8, int agility = 6, int technique = 4)
            : base(name ?? FlavorText.GenerateEnemyName())
        {
            Level = level;
            MaxHealth = maxHealth;
            CurrentHealth = maxHealth;
            Strength = strength;
            Agility = agility;
            Technique = technique;

            GoldReward = 5 + (level * 2);
            XPReward = 5 + (level * 2);

            ActionPool.Clear();
            AddDefaultActions();
        }

        private void AddDefaultActions()
        {
            var basicAttack = new Action(
                "Basic Attack",
                ActionType.Attack,
                TargetType.SingleTarget,
                baseValue: 5 + Level,
                range: 1,
                description: "A basic attack"
            );

            var jab = new Action(
                "Jab",
                ActionType.Attack,
                TargetType.SingleTarget,
                baseValue: 2 + Level, // Slightly weaker than special
                range: 1,
                description: "A quick jab"
            );

            // 70% chance for basic attack, 30% for jab
            AddAction(basicAttack, 0.7);
            AddAction(jab, 0.3);
        }

        public override string GetDescription()
        {
            return $"Level {Level} Enemy (Health: {CurrentHealth}/{MaxHealth}) (Reward: {GoldReward} gold, {XPReward} XP)";
        }

        public override string ToString()
        {
            return base.ToString();
        }

        // Add a method to Enemy to handle action selection with a roll threshold
        public string AttemptAction(Character target, Environment? environment = null)
        {
            var availableActions = new List<Action>();
            foreach (var entry in ActionPool)
            {
                availableActions.Add(entry.action);
            }
            if (availableActions.Count == 0)
                return $"{Name} has no available actions!";
            // Always use the first action (Jab) for now, or randomize if you want
            var action = availableActions[0];
            int roll = Dice.Roll(20);
            if (roll >= 10)
            {
                double effect = action.BaseValue;
                if (environment != null)
                    effect = environment.ApplyPassiveEffect(effect);
                int finalEffect = (int)effect;
                if (action.Type == ActionType.Attack)
                {
                    target.TakeDamage(finalEffect);
                    return $"[{Name}] uses [{action.Name}] on [{target.Name}]: deals {finalEffect} damage. (Rolled {roll}, need 10)";
                }
                else if (action.Type == ActionType.Debuff)
                {
                    return $"[{Name}] uses [{action.Name}] on [{target.Name}]: applies debuff. (Rolled {roll}, need 10)";
                }
                return $"[{Name}] uses [{action.Name}] on [{target.Name}]. (Rolled {roll}, need 10)";
            }
            else
            {
                return $"[{Name}] attempts [{action.Name}] but fails. (Rolled {roll}, need 10) No action performed.";
            }
        }
    }
} 