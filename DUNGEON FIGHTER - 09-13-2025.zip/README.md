# Dungeon Fighter v2 - Console RPG

## Quick Start

1. **Extract** this zip file to any folder on your computer
2. **Double-click** `DUNGEON FIGHTER.bat` to start the game
3. **Enjoy** your dungeon crawling adventure!

## System Requirements

- **Windows 10/11** (64-bit)
- **.NET 8.0 Runtime** (automatically installed on most modern Windows systems)
- **No additional software required**

## Game Description

Dungeon Fighter v2 is a sophisticated turn-based RPG/dungeon crawler featuring:

### Core Features
- **Advanced Combat System**: Turn-based combat with combo mechanics and dice-based resolution
- **Character Progression**: Level up your character with 4 different classes (Barbarian, Warrior, Rogue, Wizard)
- **Equipment System**: Weapons, armor, and loot with tier-based stats and special abilities
- **18+ Enemy Types**: Each with unique stats, abilities, and specializations
- **10 Themed Dungeons**: Forest, Lava, Crypt, Cavern, Swamp, Desert, Ice, Ruins, Castle, Graveyard
- **Procedural Generation**: 1-3 rooms per dungeon with unique environmental effects
- **Battle Narrative System**: Event-driven narrative with poetic descriptions for significant moments

### Combat Mechanics
- **Action Combo System**: Chain actions together for increased damage (1.85x multiplier per combo step)
- **Dice-based Resolution**: 1d20 roll system with thresholds (1-5 fail, 6-15 normal, 16-20 combo trigger)
- **Environmental Actions**: Room-specific effects that impact combat
- **Intelligent AI**: Enemies with specialized attributes and scaling difficulty

### Character Classes
- **Barbarian**: Strength-focused warrior with high damage output
- **Warrior**: Balanced fighter with good defense and offense
- **Rogue**: Agility-focused character with quick, precise attacks
- **Wizard**: Intelligence-based magic user with powerful spells

## How to Play

1. **Launch the game** using `DUNGEON FIGHTER.bat`
2. **Create a character** or load an existing save
3. **Select a dungeon** to explore
4. **Navigate through rooms** using the menu system
5. **Fight enemies** using your equipped weapons and armor
6. **Manage your inventory** and equipment between battles
7. **Level up** and gain new abilities as you progress

## Controls

- **Arrow Keys**: Navigate menus
- **Enter**: Select/confirm choices
- **Numbers**: Quick selection in menus
- **Any Key**: Continue through text and prompts

## Game Files

- `Code.exe` - Main game executable
- `GameData/` - Contains all game content (enemies, items, dungeons, etc.)
- `DUNGEON FIGHTER.bat` - Launcher script
- `README.md` - This file

## Troubleshooting

### Game won't start
- Make sure you have .NET 8.0 Runtime installed
- Try running `Code.exe` directly instead of `DUNGEON FIGHTER.bat`
- Check that all files are in the same folder

### Performance issues
- The game is optimized for console output and should run smoothly on any modern computer
- If you experience delays, this is intentional pacing for the narrative system

### Save files
- Character saves are stored as `character_save.json` in the game folder
- You can backup this file to preserve your progress

## Technical Details

- **Engine**: C# .NET 8.0 Console Application
- **Architecture**: Data-driven design with JSON configuration files
- **Testing**: Comprehensive test suite with 14+ test categories
- **Cross-platform**: Core systems designed for portability

## Support

This is a standalone game that requires no internet connection or additional downloads. All game data is included in the distribution package.

---

**Enjoy your dungeon crawling adventure!**
